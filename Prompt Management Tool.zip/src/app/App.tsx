import { useState, useEffect } from 'react';
import * as Tabs from '@radix-ui/react-tabs';
import * as Dialog from '@radix-ui/react-dialog';
import * as Switch from '@radix-ui/react-switch';
import { Search, Sparkles, Code2, Megaphone, ClipboardList, Folder, Rows3, Columns2, Send, Settings, X, Check, Plus, Pencil, Trash2 } from 'lucide-react';

type Prompt = { id: number; title: string; description: string; prompt: string };
type Category = { id: string; label: string; icon: any; visible: boolean };

const ICONS: Record<string, any> = { Code2, Megaphone, ClipboardList, Folder, Sparkles };

const initialCategories: Category[] = [
  { id: 'coding', label: 'Coding', icon: Code2, visible: true },
  { id: 'media',  label: '自媒体', icon: Megaphone, visible: true },
  { id: 'pm',     label: 'PM',     icon: ClipboardList, visible: true },
];

const initialPrompts: Record<string, Prompt[]> = {
  coding: [
    { id: 1, title: "代码重构助手", description: "帮助重构代码，提升代码质量和可维护性",
      prompt: "请帮我重构以下代码，要求：1. 提升可读性 2. 优化性能 3. 遵循最佳实践\n\n代码：\n[在此粘贴代码]" },
    { id: 2, title: "Bug 调试专家", description: "快速定位和修复代码中的问题",
      prompt: "我遇到了一个 bug，请帮我分析原因并提供解决方案：\n\n问题描述：[描述问题]\n错误信息：[粘贴错误]\n相关代码：[粘贴代码]" },
    { id: 3, title: "API 文档生成", description: "自动生成清晰的 API 文档",
      prompt: "请为以下 API 生成详细的文档，包括：参数说明、返回值、示例代码、注意事项\n\nAPI 代码：\n[粘贴 API 代码]" },
    { id: 4, title: "单元测试编写", description: "生成全面的单元测试用例",
      prompt: "请为以下函数/组件编写完整的单元测试，覆盖边界情况和异常场景：\n\n代码：\n[粘贴代码]" },
  ],
  media: [
    { id: 5, title: "小红书爆款标题", description: "生成吸引人的小红书标题",
      prompt: "请为以下内容生成 10 个小红书风格的标题，要求：\n1. 包含emoji\n2. 激发好奇心\n3. 突出价值点\n\n内容主题：[描述主题]" },
    { id: 6, title: "视频脚本创作", description: "创作短视频脚本和分镜",
      prompt: "请为以下主题创作一个 60 秒短视频脚本，包括：\n1. 开场吸引\n2. 内容展开\n3. 行动号召\n\n主题：[输入主题]" },
    { id: 7, title: "公众号推文优化", description: "优化公众号文章，提升阅读体验",
      prompt: "请优化以下公众号文章，要求：\n1. 提升标题吸引力\n2. 优化段落结构\n3. 增加金句\n4. 调整语气更亲和\n\n原文：\n[粘贴原文]" },
  ],
  pm: [
    { id: 8, title: "需求文档生成", description: "快速生成规范的 PRD 文档",
      prompt: "请根据以下信息生成产品需求文档(PRD)：\n\n产品概述：[描述产品]\n目标用户：[用户画像]\n核心功能：[列出功能]\n\n请包含：背景、目标、用户故事、功能清单、交互说明" },
    { id: 9, title: "用户故事拆解", description: "将需求拆解为可执行的用户故事",
      prompt: "请将以下需求拆解为用户故事，使用格式：作为[角色]，我想要[功能]，以便[价值]\n\n需求描述：[输入需求]" },
    { id: 10, title: "竞品分析报告", description: "生成结构化的竞品分析",
      prompt: "请对以下产品进行竞品分析：\n\n我的产品：[产品描述]\n竞品：[竞品名称]\n\n请从以下维度分析：\n1. 核心功能对比\n2. 用户体验\n3. 商业模式\n4. 优劣势\n5. 差异化机会" },
    { id: 11, title: "功能优先级评估", description: "使用 RICE 模型评估功能优先级",
      prompt: "请使用 RICE 模型（Reach, Impact, Confidence, Effort）评估以下功能的优先级：\n\n功能列表：\n[列出功能]" },
  ],
};

type Layout = 'one' | 'two';

const PROVIDERS = [
  { id: 'openai',    label: 'OpenAI',    placeholder: 'gpt-4o-mini' },
  { id: 'anthropic', label: 'Anthropic', placeholder: 'claude-sonnet-4' },
  { id: 'deepseek',  label: 'DeepSeek',  placeholder: 'deepseek-chat' },
  { id: 'custom',    label: '自定义',     placeholder: 'model-name' },
];

let nextPromptId = 100;

export default function App() {
  const [categories, setCategories] = useState<Category[]>(initialCategories);
  const [prompts, setPrompts] = useState<Record<string, Prompt[]>>(initialPrompts);
  const [activeTab, setActiveTab] = useState<string>('coding');
  const [searchQuery, setSearchQuery] = useState('');
  const [layout, setLayout] = useState<Layout>('two');
  const [calledId, setCalledId] = useState<number | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  const [settingsOpen, setSettingsOpen] = useState(false);
  const [addPromptOpen, setAddPromptOpen] = useState(false);

  const [aiEnabled, setAiEnabled] = useState(false);
  const [provider, setProvider] = useState('openai');
  const [model, setModel] = useState('gpt-4o-mini');
  const [apiKey, setApiKey] = useState('');
  const [baseUrl, setBaseUrl] = useState('');

  // add prompt form
  const [formTitle, setFormTitle] = useState('');
  const [formDesc, setFormDesc] = useState('');
  const [formPrompt, setFormPrompt] = useState('');
  const [formCategory, setFormCategory] = useState(activeTab);

  useEffect(() => {
    const cur = categories.find(c => c.id === activeTab && c.visible);
    if (!cur) {
      const next = categories.find(c => c.visible);
      if (next) setActiveTab(next.id);
    }
  }, [categories, activeTab]);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2000);
  };

  const handleCall = async (prompt: string, id: number) => {
    setCalledId(id);
    setTimeout(() => setCalledId(null), 1200);
    if (aiEnabled && apiKey) {
      showToast(`已调用 ${provider} · ${model}`);
    } else {
      try {
        await navigator.clipboard.writeText(prompt);
        showToast('Prompt 已复制（未配置 AI，可在设置中接入）');
      } catch { showToast('调用失败'); }
    }
  };

  const handleImport = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.xlsx,.xls';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) showToast(`准备导入：${file.name}`);
    };
    input.click();
  };
  const handleExport = () => showToast('已导出当前分类为 Excel');

  const openAddPrompt = () => {
    setFormTitle(''); setFormDesc(''); setFormPrompt(''); setFormCategory(activeTab);
    setAddPromptOpen(true);
  };

  const submitAddPrompt = () => {
    if (!formTitle.trim() || !formPrompt.trim()) {
      showToast('请填写标题和 Prompt 内容');
      return;
    }
    const newP: Prompt = { id: nextPromptId++, title: formTitle.trim(),
      description: formDesc.trim() || '自定义 Prompt', prompt: formPrompt.trim() };
    setPrompts(prev => ({ ...prev, [formCategory]: [...(prev[formCategory] || []), newP] }));
    setAddPromptOpen(false);
    setActiveTab(formCategory);
    showToast('已添加新 Prompt');
  };

  const updateCategory = (id: string, patch: Partial<Category>) => {
    setCategories(prev => prev.map(c => c.id === id ? { ...c, ...patch } : c));
  };
  const addCategory = () => {
    const id = 'cat_' + Date.now();
    setCategories(prev => [...prev, { id, label: '新分类', icon: Folder, visible: true }]);
    setPrompts(prev => ({ ...prev, [id]: [] }));
  };
  const deleteCategory = (id: string) => {
    if (categories.length <= 1) { showToast('至少保留一个分类'); return; }
    setCategories(prev => prev.filter(c => c.id !== id));
    setPrompts(prev => { const n = { ...prev }; delete n[id]; return n; });
  };

  const activeCat = categories.find(c => c.id === activeTab);
  const list = prompts[activeTab] || [];
  const filteredPrompts = list.filter(p =>
    p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.description.toLowerCase().includes(searchQuery.toLowerCase())
  );
  const visibleCats = categories.filter(c => c.visible);

  return (
    <div className="size-full overflow-auto flex flex-col relative" style={{ background: '#f3f5f8' }}>
      <style>{`
        @keyframes auraDrift1 { 0%,100% { transform: translate3d(0,0,0) scale(1);} 35% { transform: translate3d(4vw,3vh,0) scale(1.06);} 70% { transform: translate3d(-2vw,5vh,0) scale(0.98);} }
        @keyframes auraDrift2 { 0%,100% { transform: translate3d(0,0,0) scale(1);} 40% { transform: translate3d(-4vw,-3vh,0) scale(1.08);} 75% { transform: translate3d(3vw,-5vh,0) scale(0.96);} }
        @keyframes auraDrift3 { 0%,100% { transform: translate3d(0,0,0) scale(1);} 50% { transform: translate3d(2vw,-4vh,0) scale(1.05);} }
        @keyframes settingsSpin { from { transform: rotate(0); } to { transform: rotate(90deg); } }
        .aura-blob-1 { animation: auraDrift1 26s ease-in-out infinite; }
        .aura-blob-2 { animation: auraDrift2 32s ease-in-out infinite; }
        .aura-blob-3 { animation: auraDrift3 30s ease-in-out infinite; }
        .settings-btn:hover svg { animation: settingsSpin 0.4s ease forwards; }
      `}</style>
      <div className="fixed inset-0 z-0 overflow-hidden pointer-events-none">
        <div className="aura-blob-1 absolute" style={{ top:'-12%', left:'-12%', width:'52vw', height:'52vw', borderRadius:'50%', background:'rgba(191,219,254,0.35)', filter:'blur(120px)' }} />
        <div className="aura-blob-2 absolute" style={{ top:'18%', right:'-15%', width:'46vw', height:'46vw', borderRadius:'50%', background:'rgba(216,180,254,0.28)', filter:'blur(120px)' }} />
        <div className="aura-blob-3 absolute" style={{ bottom:'-15%', left:'20%', width:'40vw', height:'40vw', borderRadius:'50%', background:'rgba(199,210,254,0.30)', filter:'blur(110px)' }} />
      </div>

      <div className="relative z-10 flex flex-col size-full">
        {/* Nav */}
        <div className="px-6 pt-4 pb-2 sticky top-0 z-40">
          <nav className="mx-auto max-w-[1100px] flex items-center justify-between rounded-full border px-3 py-2 pl-5"
            style={{ background: 'rgba(255,255,255,0.78)', backdropFilter: 'blur(16px)',
              WebkitBackdropFilter: 'blur(16px)', borderColor: 'rgba(255,255,255,0.9)',
              boxShadow: '0 4px 24px rgba(15,23,42,0.06)' }}>
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-full grid place-items-center border"
                style={{ background: 'linear-gradient(135deg,#d4e3ff,#fff7fb)', borderColor: '#dce6f5' }}>
                <Sparkles className="w-4 h-4" style={{ color: '#3b63ff' }} />
              </div>
              <div className="leading-tight">
                <div style={{ fontSize: 14, fontWeight: 700, color: '#0f172a' }}>Prompt 管理器</div>
                <div style={{ fontSize: 10, color: '#94a3b8' }}>AI Prompt Library</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={handleImport}
                className="inline-flex items-center rounded-full border transition-all hover:bg-[#f8faff]"
                style={{ padding: '8px 16px', fontSize: 13, borderColor: '#e2e8f0', color: '#0f172a' }}>
                导入
              </button>
              <button onClick={handleExport}
                className="inline-flex items-center rounded-full text-white transition-all hover:-translate-y-0.5"
                style={{ padding: '8px 18px', fontSize: 13, background: '#0f172a',
                  boxShadow: '0 4px 14px rgba(15,23,42,0.18)' }}>
                导出 Excel
              </button>
              <button onClick={() => setSettingsOpen(true)}
                className="settings-btn grid place-items-center rounded-full border transition-all hover:bg-[#f8faff]"
                style={{ width: 36, height: 36, borderColor: '#e2e8f0', color: '#475569' }} title="设置">
                <Settings className="w-4 h-4" />
              </button>
            </div>
          </nav>
        </div>

        {/* Main */}
        <div className="flex-1 max-w-[1100px] w-full mx-auto px-6 pt-6 pb-16">
          <div className="mb-5">
            <div className="relative rounded-full border"
              style={{ background: 'rgba(255,255,255,0.9)', borderColor: '#e2e8f0',
                boxShadow: '0 4px 20px rgba(15,23,42,0.04)' }}>
              <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: '#94a3b8' }} />
              <input type="text" placeholder="搜索 Prompt 名称或描述..."
                value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-transparent focus:outline-none"
                style={{ padding: '12px 20px 12px 48px', fontSize: 14, color: '#0f172a' }} />
            </div>
          </div>

          <Tabs.Root value={activeTab} onValueChange={setActiveTab}>
            <div className="flex items-center justify-between mb-5 gap-3 flex-wrap">
              <Tabs.List className="inline-flex p-1 rounded-full border flex-wrap"
                style={{ background: 'rgba(255,255,255,0.7)', borderColor: '#e2e8f0',
                  boxShadow: '0 4px 14px rgba(15,23,42,0.04)' }}>
                {visibleCats.map((cat) => {
                  const Icon = cat.icon;
                  const active = activeTab === cat.id;
                  const count = (prompts[cat.id] || []).length;
                  return (
                    <Tabs.Trigger key={cat.id} value={cat.id}
                      className="inline-flex items-center gap-2 rounded-full transition-all"
                      style={{ padding: '8px 16px', fontSize: 13, fontWeight: 500,
                        color: active ? '#fff' : '#475569',
                        background: active ? '#0f172a' : 'transparent',
                        boxShadow: active ? '0 4px 14px rgba(15,23,42,0.2)' : 'none' }}>
                      <Icon className="w-3.5 h-3.5" />
                      {cat.label}
                      <span className="rounded-full px-1.5"
                        style={{ fontSize: 11,
                          background: active ? 'rgba(255,255,255,0.18)' : '#eef2ff',
                          color: active ? '#fff' : '#3b63ff' }}>
                        {count}
                      </span>
                    </Tabs.Trigger>
                  );
                })}
              </Tabs.List>

              <div className="flex items-center gap-2">
                <button onClick={openAddPrompt}
                  className="grid place-items-center rounded-full transition-all active:scale-95 hover:-translate-y-0.5"
                  style={{ width: 36, height: 36, color: '#fff',
                    background: 'linear-gradient(135deg,#3b63ff,#6366f1)',
                    boxShadow: '0 4px 14px rgba(59,99,255,0.32)' }}
                  title="新增 Prompt">
                  <Plus className="w-4 h-4" />
                </button>
                <div className="inline-flex p-1 rounded-full border"
                  style={{ background: 'rgba(255,255,255,0.7)', borderColor: '#e2e8f0' }}>
                  <button onClick={() => setLayout('one')}
                    className="rounded-full transition-all grid place-items-center"
                    style={{ width: 32, height: 32,
                      background: layout === 'one' ? '#0f172a' : 'transparent',
                      color: layout === 'one' ? '#fff' : '#64748b' }} title="单列">
                    <Rows3 className="w-4 h-4" />
                  </button>
                  <button onClick={() => setLayout('two')}
                    className="rounded-full transition-all grid place-items-center"
                    style={{ width: 32, height: 32,
                      background: layout === 'two' ? '#0f172a' : 'transparent',
                      color: layout === 'two' ? '#fff' : '#64748b' }} title="双列">
                    <Columns2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

            <Tabs.Content value={activeTab}>
              <div className={`grid gap-3 ${layout === 'two' ? 'grid-cols-2' : 'grid-cols-1'}`}>
                {filteredPrompts.map((prompt) => {
                  const called = calledId === prompt.id;
                  return (
                    <div key={prompt.id}
                      className="group relative rounded-2xl border px-5 py-4 transition-all hover:-translate-y-0.5 flex items-center gap-4"
                      style={{ background: 'rgba(255,255,255,0.85)', backdropFilter: 'blur(10px)',
                        borderColor: called ? '#3b63ff' : 'rgba(226,232,240,0.8)',
                        boxShadow: called ? '0 8px 28px rgba(59,99,255,0.22)' : '0 4px 16px rgba(15,23,42,0.04)' }}>
                      <div className="flex-1 min-w-0">
                        <h3 className="truncate mb-1" style={{ fontSize: 15, fontWeight: 600, color: '#0f172a' }}>
                          {prompt.title}
                        </h3>
                        <p className="line-clamp-1" style={{ fontSize: 12.5, color: '#64748b' }}>
                          {prompt.description}
                        </p>
                      </div>
                      <button onClick={() => handleCall(prompt.prompt, prompt.id)}
                        className="shrink-0 inline-flex items-center gap-1.5 rounded-full transition-all active:scale-95 hover:-translate-y-0.5"
                        style={{ padding: '8px 14px', fontSize: 12.5, fontWeight: 500, color: '#fff',
                          background: called
                            ? 'linear-gradient(135deg,#10b981,#059669)'
                            : 'linear-gradient(135deg,#3b63ff,#6366f1)',
                          boxShadow: called
                            ? '0 6px 18px rgba(16,185,129,0.35)'
                            : '0 4px 14px rgba(59,99,255,0.28)',
                          transform: called ? 'scale(1.04)' : undefined }}>
                        {called ? (<><Check className="w-3.5 h-3.5" />已调用</>) : (<><Send className="w-3.5 h-3.5" />调用</>)}
                      </button>
                    </div>
                  );
                })}
              </div>

              {filteredPrompts.length === 0 && (
                <div className="text-center py-16 rounded-2xl border"
                  style={{ background: 'rgba(255,255,255,0.6)', borderColor: '#e2e8f0',
                    color: '#94a3b8', fontSize: 14 }}>
                  {searchQuery ? '未找到匹配的 Prompt ✨' : '当前分类还没有 Prompt，点击右上 + 添加一个'}
                </div>
              )}
            </Tabs.Content>
          </Tabs.Root>
        </div>
      </div>

      {/* Toast */}
      {toast && (
        <div className="fixed left-1/2 -translate-x-1/2 bottom-8 z-[60] rounded-full px-5 py-2.5 border"
          style={{ background: 'rgba(15,23,42,0.92)', color: '#fff', fontSize: 13,
            borderColor: 'rgba(255,255,255,0.1)', boxShadow: '0 8px 28px rgba(15,23,42,0.25)' }}>
          {toast}
        </div>
      )}

      {/* Add Prompt Dialog */}
      <Dialog.Root open={addPromptOpen} onOpenChange={setAddPromptOpen}>
        <Dialog.Portal>
          <Dialog.Overlay className="fixed inset-0 z-50"
            style={{ background: 'rgba(15,23,42,0.35)', backdropFilter: 'blur(4px)' }} />
          <Dialog.Content
            className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-[520px] max-w-[92vw] rounded-3xl border"
            style={{ background: '#fff', borderColor: '#e2e8f0',
              boxShadow: '0 24px 60px rgba(15,23,42,0.18)' }}>
            <div className="flex items-center justify-between px-6 pt-5 pb-3 border-b" style={{ borderColor: '#f1f5f9' }}>
              <Dialog.Title style={{ fontSize: 16, fontWeight: 600, color: '#0f172a' }}>新增 Prompt</Dialog.Title>
              <Dialog.Close className="grid place-items-center rounded-full hover:bg-slate-100"
                style={{ width: 32, height: 32, color: '#64748b' }}>
                <X className="w-4 h-4" />
              </Dialog.Close>
            </div>
            <div className="px-6 py-5 space-y-4 max-h-[70vh] overflow-y-auto">
              <div>
                <label style={{ fontSize: 11, color: '#64748b' }}>分类</label>
                <div className="flex flex-wrap gap-1.5 mt-1.5">
                  {categories.map(c => (
                    <button key={c.id} onClick={() => setFormCategory(c.id)}
                      className="rounded-full border transition-all"
                      style={{ padding: '6px 12px', fontSize: 12,
                        borderColor: formCategory === c.id ? '#0f172a' : '#e2e8f0',
                        background: formCategory === c.id ? '#0f172a' : '#fff',
                        color: formCategory === c.id ? '#fff' : '#475569' }}>
                      {c.label}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label style={{ fontSize: 11, color: '#64748b' }}>标题</label>
                <input value={formTitle} onChange={(e) => setFormTitle(e.target.value)}
                  placeholder="例如：代码重构助手"
                  className="w-full mt-1.5 rounded-lg border px-3 py-2 focus:outline-none focus:border-[#0f172a]"
                  style={{ fontSize: 13, borderColor: '#e2e8f0' }} />
              </div>
              <div>
                <label style={{ fontSize: 11, color: '#64748b' }}>简介</label>
                <input value={formDesc} onChange={(e) => setFormDesc(e.target.value)}
                  placeholder="一句话说明这个 Prompt 的用途"
                  className="w-full mt-1.5 rounded-lg border px-3 py-2 focus:outline-none focus:border-[#0f172a]"
                  style={{ fontSize: 13, borderColor: '#e2e8f0' }} />
              </div>
              <div>
                <label style={{ fontSize: 11, color: '#64748b' }}>Prompt 内容</label>
                <textarea value={formPrompt} onChange={(e) => setFormPrompt(e.target.value)}
                  placeholder="输入完整的 Prompt 内容..."
                  rows={6}
                  className="w-full mt-1.5 rounded-lg border px-3 py-2 focus:outline-none focus:border-[#0f172a] resize-none"
                  style={{ fontSize: 13, borderColor: '#e2e8f0', fontFamily: 'ui-monospace, monospace', lineHeight: 1.6 }} />
              </div>
            </div>
            <div className="flex justify-end gap-2 px-6 py-4 border-t" style={{ borderColor: '#f1f5f9' }}>
              <Dialog.Close
                className="rounded-full border px-5 py-2 transition-colors hover:bg-slate-50"
                style={{ fontSize: 13, borderColor: '#e2e8f0', color: '#475569' }}>
                取消
              </Dialog.Close>
              <button onClick={submitAddPrompt}
                className="rounded-full text-white px-5 py-2 transition-all hover:-translate-y-0.5"
                style={{ fontSize: 13, background: 'linear-gradient(135deg,#3b63ff,#6366f1)',
                  boxShadow: '0 4px 14px rgba(59,99,255,0.28)' }}>
                添加
              </button>
            </div>
          </Dialog.Content>
        </Dialog.Portal>
      </Dialog.Root>

      {/* Settings Dialog */}
      <Dialog.Root open={settingsOpen} onOpenChange={setSettingsOpen}>
        <Dialog.Portal>
          <Dialog.Overlay className="fixed inset-0 z-50"
            style={{ background: 'rgba(15,23,42,0.35)', backdropFilter: 'blur(4px)' }} />
          <Dialog.Content
            className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-[520px] max-w-[92vw] rounded-3xl border"
            style={{ background: '#fff', borderColor: '#e2e8f0',
              boxShadow: '0 24px 60px rgba(15,23,42,0.18)' }}>
            <div className="flex items-center justify-between px-6 pt-5 pb-3 border-b" style={{ borderColor: '#f1f5f9' }}>
              <Dialog.Title style={{ fontSize: 16, fontWeight: 600, color: '#0f172a' }}>设置</Dialog.Title>
              <Dialog.Close className="grid place-items-center rounded-full hover:bg-slate-100"
                style={{ width: 32, height: 32, color: '#64748b' }}>
                <X className="w-4 h-4" />
              </Dialog.Close>
            </div>

            <div className="px-6 py-5 space-y-6 max-h-[70vh] overflow-y-auto">
              {/* Categories */}
              <section>
                <div className="flex items-center justify-between mb-2.5">
                  <div style={{ fontSize: 13, fontWeight: 600, color: '#0f172a' }}>分类管理</div>
                  <button onClick={addCategory}
                    className="inline-flex items-center gap-1 rounded-full border transition-colors hover:bg-slate-50"
                    style={{ padding: '5px 12px', fontSize: 12, borderColor: '#e2e8f0', color: '#0f172a' }}>
                    <Plus className="w-3 h-3" />新增分类
                  </button>
                </div>
                <div style={{ fontSize: 11, color: '#94a3b8', marginBottom: 10 }}>
                  可以编辑分类名称、控制是否显示，或新增自定义分类
                </div>
                <div className="space-y-2">
                  {categories.map((cat) => {
                    const Icon = cat.icon;
                    return (
                      <div key={cat.id}
                        className="flex items-center gap-2 rounded-xl border px-3 py-2"
                        style={{ borderColor: '#e2e8f0' }}>
                        <Icon className="w-4 h-4 shrink-0" style={{ color: '#3b63ff' }} />
                        <input
                          value={cat.label}
                          onChange={(e) => updateCategory(cat.id, { label: e.target.value })}
                          className="flex-1 bg-transparent focus:outline-none rounded px-2 py-1 hover:bg-slate-50 focus:bg-slate-50"
                          style={{ fontSize: 13, color: '#0f172a' }}
                        />
                        <Pencil className="w-3 h-3" style={{ color: '#cbd5e1' }} />
                        <Switch.Root
                          checked={cat.visible}
                          onCheckedChange={(v) => updateCategory(cat.id, { visible: v })}
                          className="relative rounded-full transition-colors shrink-0"
                          style={{ width: 36, height: 20, background: cat.visible ? '#0f172a' : '#cbd5e1' }}>
                          <Switch.Thumb className="block rounded-full bg-white transition-transform"
                            style={{ width: 16, height: 16, transform: `translateX(${cat.visible ? 18 : 2}px) translateY(2px)`,
                              boxShadow: '0 1px 2px rgba(0,0,0,0.2)' }} />
                        </Switch.Root>
                        <button onClick={() => deleteCategory(cat.id)}
                          className="grid place-items-center rounded-full hover:bg-red-50 shrink-0"
                          style={{ width: 28, height: 28, color: '#94a3b8' }}
                          title="删除分类">
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    );
                  })}
                </div>
              </section>

              {/* AI Integration */}
              <section>
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 600, color: '#0f172a' }}>接入 AI 大模型</div>
                    <div style={{ fontSize: 11, color: '#94a3b8', marginTop: 2 }}>
                      启用后，"调用"按钮将直接发送到所选模型
                    </div>
                  </div>
                  <Switch.Root checked={aiEnabled} onCheckedChange={setAiEnabled}
                    className="relative rounded-full transition-colors"
                    style={{ width: 36, height: 20, background: aiEnabled ? '#0f172a' : '#cbd5e1' }}>
                    <Switch.Thumb className="block rounded-full bg-white transition-transform"
                      style={{ width: 16, height: 16, transform: `translateX(${aiEnabled ? 18 : 2}px) translateY(2px)`,
                        boxShadow: '0 1px 2px rgba(0,0,0,0.2)' }} />
                  </Switch.Root>
                </div>
                <div className={`space-y-3 transition-opacity ${aiEnabled ? '' : 'opacity-50 pointer-events-none'}`}>
                  <div>
                    <label style={{ fontSize: 11, color: '#64748b' }}>服务商</label>
                    <div className="grid grid-cols-4 gap-1.5 mt-1.5">
                      {PROVIDERS.map(p => (
                        <button key={p.id} onClick={() => { setProvider(p.id); setModel(p.placeholder); }}
                          className="rounded-lg border transition-all"
                          style={{ padding: '7px 8px', fontSize: 12,
                            borderColor: provider === p.id ? '#0f172a' : '#e2e8f0',
                            background: provider === p.id ? '#0f172a' : '#fff',
                            color: provider === p.id ? '#fff' : '#475569' }}>
                          {p.label}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label style={{ fontSize: 11, color: '#64748b' }}>模型</label>
                    <input value={model} onChange={(e) => setModel(e.target.value)}
                      placeholder="model-name"
                      className="w-full mt-1.5 rounded-lg border px-3 py-2 focus:outline-none focus:border-[#0f172a]"
                      style={{ fontSize: 13, borderColor: '#e2e8f0' }} />
                  </div>
                  <div>
                    <label style={{ fontSize: 11, color: '#64748b' }}>API Key</label>
                    <input value={apiKey} onChange={(e) => setApiKey(e.target.value)}
                      type="password" placeholder="sk-..."
                      className="w-full mt-1.5 rounded-lg border px-3 py-2 focus:outline-none focus:border-[#0f172a]"
                      style={{ fontSize: 13, borderColor: '#e2e8f0', fontFamily: 'ui-monospace, monospace' }} />
                  </div>
                  <div>
                    <label style={{ fontSize: 11, color: '#64748b' }}>Base URL（可选）</label>
                    <input value={baseUrl} onChange={(e) => setBaseUrl(e.target.value)}
                      placeholder="https://api.example.com/v1"
                      className="w-full mt-1.5 rounded-lg border px-3 py-2 focus:outline-none focus:border-[#0f172a]"
                      style={{ fontSize: 13, borderColor: '#e2e8f0' }} />
                  </div>
                </div>
              </section>
            </div>

            <div className="flex justify-end gap-2 px-6 py-4 border-t" style={{ borderColor: '#f1f5f9' }}>
              <Dialog.Close
                className="rounded-full border px-5 py-2 transition-colors hover:bg-slate-50"
                style={{ fontSize: 13, borderColor: '#e2e8f0', color: '#475569' }}>
                取消
              </Dialog.Close>
              <button onClick={() => { setSettingsOpen(false); showToast('设置已保存'); }}
                className="rounded-full text-white px-5 py-2 transition-all hover:-translate-y-0.5"
                style={{ fontSize: 13, background: '#0f172a',
                  boxShadow: '0 4px 14px rgba(15,23,42,0.18)' }}>
                保存
              </button>
            </div>
          </Dialog.Content>
        </Dialog.Portal>
      </Dialog.Root>
    </div>
  );
}


  # Prompt Management Tool

  This is a code bundle for Prompt Management Tool. The original project is available at https://www.figma.com/design/bvaEqZ2FuC0gEmUXBYNRji/Prompt-Management-Tool.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  